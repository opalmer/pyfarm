import sys

print "Hello from cx_Freeze Advanced #1"
print

module = __import__("testfreeze_1")

