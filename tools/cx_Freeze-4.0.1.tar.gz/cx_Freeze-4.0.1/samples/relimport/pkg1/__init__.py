print "importing pkg1"
from . import sub1
from . import pkg2
