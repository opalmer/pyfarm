print "importing pkg1.pkg2"
from . import sub3
from .. import sub4
